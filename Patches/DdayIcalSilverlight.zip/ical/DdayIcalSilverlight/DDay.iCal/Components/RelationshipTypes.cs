using System;
using System.Collections.Generic;
using System.Text;

namespace DDay.iCal.Components
{
    public class RelationshipTypes
    {
        public const string Parent = "PARENT";
        public const string Child = "CHILD";
        public const string Sibling = "SIBLING";        
    }
}
