Visual Studio 2008 Solution containing the projects:

antlrsilverlight\
  ANTLR runtime version 2.7.7 ported from C# to Silverlight
SilverlightAdapter\
  Reimplementation of classes missing in Silverlight like
  'ArrayList' and 'Hash' and some stubs (like XMLTestWriter) 
  to ease porting to Silverlight.
DdayIcalSilverlight\
  Dday.Ical 0.70 ported from C# to Silverlight
  Disabled functionality: XML writing & loading from URIs
SilverlightApplication2\
  Application which instantiates Dday.iCalendar. Based on
  'example1' of Dday.Ical .

Requirements:
  - Silverlight 3 beta
  - Visual Studio 2008 SP1
  - Silverlight tools for Visual Studio
  
Rutger Nijlunsing <rutger.nijlunsing@gmail.com>
2009-05-21
