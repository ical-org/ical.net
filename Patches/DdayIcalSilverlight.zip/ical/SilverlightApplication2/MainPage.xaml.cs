﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using DDay.iCal;
using DDay.iCal.DataTypes;
using DDay.iCal.Components;

namespace SilverlightApplication2 {
    public partial class MainPage : UserControl {
        /// <summary>
        /// Returns 12:00 AM of the first day of the current month
        /// </summary>
        public DateTime StartOfMonth {
            get { return new DateTime(2006, 7, 1); }
        }

        /// <summary>
        /// Returns 11:59 PM of the last day of the current month
        /// </summary>
        public DateTime EndOfMonth {
            get { return StartOfMonth.AddMonths(1).AddSeconds(-1); }
        }


        public MainPage() {
            InitializeComponent();
            iCalendarCollection calendars = new iCalendarCollection();
            var uri = new Uri("test.ics", UriKind.Relative);
            var rs = Application.GetResourceStream(uri);
            var s = rs.Stream;
            var calendar = iCalendar.LoadFromStream(s);
            calendars.Add(calendar);
            var occurrences = calendars.GetOccurrences<Event>(StartOfMonth, EndOfMonth);

        }
    }
}
