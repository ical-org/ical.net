using System;
using System.Collections.Generic;
using System.Text;

namespace DDay.iCal.Serialization.iCalendar
{
    public partial class iCalParser
    {
        public Type iCalendarType;
    }
}
