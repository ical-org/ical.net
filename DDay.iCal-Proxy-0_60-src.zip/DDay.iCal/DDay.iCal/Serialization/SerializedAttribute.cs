using System;
using System.Collections.Generic;
using System.Text;

namespace DDay.iCal.Serialization
{
    /// <summary>
    /// Indicates that the property should be serialized.
    /// </summary>
    public class SerializedAttribute : Attribute
    {
    }
}
