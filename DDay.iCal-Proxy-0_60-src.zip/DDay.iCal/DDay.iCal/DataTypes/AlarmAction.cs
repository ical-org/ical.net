using System;
using System.Collections.Generic;
using System.Text;

namespace DDay.iCal.DataTypes
{
    public enum AlarmAction
    {
        Audio,
        Display,
        Email,
        Procedure
    };
}
